namespace TelephoneDirectory
{
    public class Program
    {
        public static void Main()
        {
            App app = new App();
            app.Run();
        }
    }
}